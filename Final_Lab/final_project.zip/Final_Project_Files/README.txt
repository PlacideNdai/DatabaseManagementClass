a) My database has data about a website that collect and host events about poems. The data types are string, the poems, name, etc. Int, date ie birthday and so on. The data was from www.mockaroo.com. all the data collected were of length 1000.

b) To execute my program, all you need is to know which tables (which are already mentioned in the first questions) and then answering the question as asked. For all ID related question, just use ID and for table just the table name. 

c) Based on my work, I am expecting at least 95 because I did level 2 for the phase 1, level 1 and half of level 2, and then I also did the Python level 1. Since, I did not complete level 2 as a whole, but I did Python level. I think 95 is fair.  

D) challenges I faced: I faced a lot of challenges starting with my data. I had to clean the data using python in order to save time. changing the data, dropping columns, replacing chars and more. I also was not able to insert the data using sql even with the help from the internet, I still could not do it, but I was lucky that python was able to insert the data which took a while. I am sure you got my email about inserting error(haha, it did stress me out a little.)
